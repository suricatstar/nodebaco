
const carros = [
    {
        placa: 'ABC-1234',
        modelo: 'Toyota Corolla',
        ano: 2019
    },
    {
        placa: 'DEF-5678',
        modelo: 'Honda Civic',
        ano: 2020
    },
    {
        placa: 'GHI-9012',
        modelo: 'Ford Focus',
        ano: 2018
    },
    {
        placa: 'JKL-3456',
        modelo: 'Chevrolet Cruze',
        ano: 2021
    }
];

module.exports = carros;

// console.log(carros);